export { default } from "@/components/booking";
