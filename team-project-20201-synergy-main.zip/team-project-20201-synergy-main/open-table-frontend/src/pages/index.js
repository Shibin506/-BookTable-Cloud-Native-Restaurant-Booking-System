export { default } from "@/components/home";
