// src/components/adminLayout/index.js
export { default } from './AdminLayout';