export { default } from "./RestaurantCard";
