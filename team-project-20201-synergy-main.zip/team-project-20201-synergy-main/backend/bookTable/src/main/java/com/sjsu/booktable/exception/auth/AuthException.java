package com.sjsu.booktable.exception.auth;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class AuthException extends RuntimeException {

    private final HttpStatus status;

    public AuthException(String message, HttpStatus httpStatus) {
        super(message);
        this.status = httpStatus;
    }

}
