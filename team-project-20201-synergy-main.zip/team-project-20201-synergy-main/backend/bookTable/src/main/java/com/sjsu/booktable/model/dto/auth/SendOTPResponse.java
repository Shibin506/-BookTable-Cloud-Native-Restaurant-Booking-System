package com.sjsu.booktable.model.dto.auth;

import lombok.Data;

@Data
public class SendOTPResponse {

    private String session;
}
