package com.sjsu.booktable.model.dto.auth;

import lombok.Data;

@Data
public class LogoutResponse {

    private String message;
}
