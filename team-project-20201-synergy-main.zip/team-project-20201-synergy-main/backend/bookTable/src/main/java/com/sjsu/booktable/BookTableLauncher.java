package com.sjsu.booktable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookTableLauncher {

	public static void main(String[] args) {
		SpringApplication.run(BookTableLauncher.class, args);
	}

}
